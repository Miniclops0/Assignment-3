bottleneck = 1.0e-13 * [0.1713    0.1325    0.0966    0.0492    0.0258];

bottleneck_size = [40 30 20 10 2];

figure(1)
plot(bottleneck_size, bottleneck,'b--o')
title("Avg Current at Varying Bottleneck Sizes")
xlabel("Bottleneck size (nm)")
ylabel("Avg Current (A)")
